import linecache
import numpy as np
import math

nGen = 100
line1row = 3
line2row = 4
lineSigma = 8

fileOut = open('covariance.dat', 'w')
for currentG in [str(g+1).zfill(3) for g in range(nGen)]:
	fileIn = 'generation' + currentG + '/param_gauss.dat'
	sigma = float(linecache.getline(fileIn, lineSigma))
	firstRow = [float(n) for n in linecache.getline(fileIn, line1row).split()]
	secondRow = [float(n) for n in linecache.getline(fileIn, line2row).split()]
	fileOut.write(str(firstRow[0]*(sigma**2)) + ' ' + str(firstRow[1]*(sigma**2)) + ' ' + str(secondRow[0]*(sigma**2)) + ' ' + str(secondRow[1]*(sigma**2)) + '\n')
fileOut.close()
