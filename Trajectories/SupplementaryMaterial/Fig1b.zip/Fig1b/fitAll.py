import linecache
import numpy as np
import math
import sys

nGen = int(sys.argv[1])
nSamples = int(sys.argv[2])

fileOut = open('fitness.dat', 'w')
for currentG in [str(g+1).zfill(3) for g in range(nGen)]:
	for currentS in range(nSamples):
		fileIn = 'generation' + currentG + '/sample' + str(currentS) + '/fitness.dat'
		fit = float(linecache.getline(fileIn, 1))
		fileOut.write(str(fit) + ' ')
	fileOut.write('\n')
fileOut.close()
