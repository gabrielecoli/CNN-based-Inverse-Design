gcc -ffast-math -O3 -o mc.o mc.c -lm -Wall
gcc -Wall -o letitgo letitgo.c -lm

