time ./mc.o $1 $2

