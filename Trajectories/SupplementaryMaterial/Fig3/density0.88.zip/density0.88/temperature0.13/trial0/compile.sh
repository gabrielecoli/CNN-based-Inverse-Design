gcc -ffast-math -O3 -o mc.o mc.c -lm -Wall
