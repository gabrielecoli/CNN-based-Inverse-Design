//
//  letitgo.c
//  
//
//  Created by Gabriele Maria Coli on 07/03/19.
//
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <unistd.h>

#define NSamples 10
#define InitGeneration 1
#define MaxGeneration 100

//================================================ MAIN ================================================//


int main(void){
    
    int i,j;
    char CycleCommand[60];
    char SetupCommand[60];
    char GenerationCommand[60];
    char FileName[80];
    int StillRunning, Check;
    FILE *fpfile;

    if(InitGeneration==1){
    	system("bash ./init_setup.sh");
    	system("python init_generation.py");
    } else {
    	sprintf(SetupCommand, "bash ./new_setup.sh %03d", InitGeneration);
    	system(SetupCommand);
    	sprintf(GenerationCommand, "python new_generation.py %03d", InitGeneration);
   		system(GenerationCommand);
    }


    for(i=InitGeneration;i<MaxGeneration;i++){
    	printf("Generation n. %03d is on the go!\n", i);
    	sprintf(CycleCommand, "bash ./cycle.sh %03d", i);
    	system(CycleCommand);
    	StillRunning = NSamples;

    	// qui ci va la parte di lettura delle flag per controllare che tutti abbiano finito
    	while(StillRunning>0){
		    sleep(60);
    		StillRunning = 0;
    		for(j=0;j<NSamples;j++){
    			sprintf(FileName, "../generation%03d/sample%01d/flag.dat", i, j);
    			if((fpfile = fopen(FileName,"r"))==NULL){
    				//printf("Flag file of sample n. %01d read before the creation: not a real problem\n", j);
        			StillRunning++;
    			} else {
    				//fscanf(fpfile, "%d", &Check);
    				fclose(fpfile);
    				//if(Check==0){
    					//printf("Wait! Sample n. %01d is still on the run.\nFlag value = %d\n", j, Check);
    					//StillRunning++;
    				//} else if(Check!=1){
    					//printf("Error! Unexpected flag value in sample n. %01d.\nFlag value = %d\n", j, Check);
    					//exit(0);
    				//}
    			}
    		}
    	}
    	//

    	if(StillRunning==0){
    		system("rm Q_Single*");
		sprintf(SetupCommand, "python predict.py %d", i);
		system(SetupCommand);
    		sprintf(SetupCommand, "bash ./new_setup.sh %03d", (i+1));
    		system(SetupCommand);
    		sprintf(GenerationCommand, "python new_generation.py %03d", (i+1));
    		system(GenerationCommand);
    	}
    }



    exit(0);
}
