mkdir ../generation001
mkdir ../generation001/sample0

for n in 1 2 3 4 5 6 7 8 9
do
	cp -r ../generation001/sample0 ../generation001/sample$n
done

