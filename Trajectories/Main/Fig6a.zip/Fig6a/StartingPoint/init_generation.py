import math
import numpy as np
import sys

DIM = 2
nSamples = 10
thisLambda = 1.35
filepath = '../generation001/'

gauss_file = filepath + 'param_gauss.dat'
sample_file = filepath + 'param_sample.dat'

fgauss = open(gauss_file, 'w')
fsample = open(sample_file, 'w')

MeanValues = np.empty(DIM)
Cov = np.zeros(DIM**2).reshape(DIM,DIM)


MeanValues[0] = 0.225
MeanValues[1] = 0.11

Lowest = [0.13,0.02]
Highest = [0.30,0.16]

sigma = 0.1*(np.amin(MeanValues))

Cov[0][0] = ((MeanValues[0]/MeanValues[1])**2)*sigma*sigma
Cov[1][1] = 1.0*sigma*sigma
#Cov[2][2] = (MeanValues[2]/MeanValues[0])*sigma*sigma

#scrivere sul file param_gauss i parametri di questa gaussiana
for i in range(DIM):
	fgauss.write(str(MeanValues[i]) + ' ')
fgauss.write('\n\n')
for i in range(DIM):
	for j in range(DIM):
		fgauss.write(str((Cov[i][j])/(sigma*sigma)) + ' ')
	fgauss.write('\n')
fgauss.write('\n')
for i in range(DIM):
	fgauss.write('0 ')
fgauss.write('\n\n')
fgauss.write(str(sigma) + '\n\n')
for i in range(DIM):
	fgauss.write('0 ')
fgauss.write('\n')

traj_file = '../trajectory.dat'
ftraj = open(traj_file, 'a')
ftraj.write('001 ')
for i in range(DIM):
	ftraj.write(str(MeanValues[i]) + ' ')
ftraj.write('\n')
ftraj.close()

samples = []

for i in range(nSamples):
	while(True):
		k = 0
   		samples.append(np.random.multivariate_normal(MeanValues,Cov))
   		#print(samples)
   		for j in range(DIM):
			if samples[i][j] < Lowest[j]:
				k += 1
			if samples[i][j] > Highest[j]:
				k += 1
		if k == 0:
			break
		else:
			samples.pop()

#scrivere sul file param_sample i parametri dei prossimi sample
for i in range(nSamples):
	fsample.write(str(i) + ' ')
	for j in range(DIM):
		fsample.write(str(samples[i][j]) +' ')
	fsample.write('\n')

for i in range(nSamples):
	file_name_siminfo = filepath + 'sample' + str(i) + '/siminfo.dat'
	fpinfo = open(file_name_siminfo, 'w+')
	for j in range(DIM):
		fpinfo.write(str(samples[i][j]) +' ')
	fpinfo.write(str(thisLambda))
	fpinfo.close()


