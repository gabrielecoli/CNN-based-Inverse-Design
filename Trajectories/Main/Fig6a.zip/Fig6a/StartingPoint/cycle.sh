for n in 0 1 2 3 4 5 6 7 8 9
do
	qsub -cwd -V -N RODS3D run.sh $1 $n
done

