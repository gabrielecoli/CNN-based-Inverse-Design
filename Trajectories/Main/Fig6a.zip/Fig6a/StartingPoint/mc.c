#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "mc.h"

int main(int argc, char **argv) {
  spherocylinder *par;
  box B;
  unsigned long long int Nattempts_dis = 0, Naccepted_dis = 0, n;
  unsigned long long int Nattempts_vol = 0, Naccepted_vol = 0;
  unsigned long long int Nattempts_rot = 0, Naccepted_rot = 0;
  #ifdef NPT
  double density;
  FILE *den;
  #endif
  double acceptance_dis, acceptance_vol, acceptance_rot, energy;
  double av_energy = 0.0, av_density = 0.0;
  int Nmeasures = 0;
  int i;
  double DeltaPos, DeltaL, DeltaRot, minL;
  vector scaling;
  FILE *en, *acc, *info, *fpsiminfo, *fpflag;
  char file_string[150];

  scaling.x = 1.0;
  scaling.y = 1.0;
  scaling.z = 1.0;


  sprintf(file_string, "../generation%s/sample%s/siminfo.dat", argv[1], argv[2]);
  if((fpsiminfo = fopen(file_string,"r"))==NULL){
      printf("ERROR: File with simulation parameters could not be opened.\n");
      exit(0);
  }
  fscanf(fpsiminfo, "%lf %lf %lf", &T, &InitDensity, &sigma1);
  init_param(&B, &DeltaPos, &DeltaL, &DeltaRot);

  par = (spherocylinder *) malloc(Npart * sizeof(spherocylinder));
  if(par == NULL) {
    printf("\nERROR: Malloc of par failed.\n");
  }



  if(InitConf==0) {
    init_smectic_conf(par, B);
  }
  else if(InitConf==1) {
    init_sc_conf(par, B);
  }
  else if(InitConf==2){
    init_hex_conf(par, B);
  }
  else {
    init_rand_conf(par, B);
  }
  n = 0;
  //print_snapshot(par, B, n, argv);

  sprintf(file_string, "../generation%s/sample%s/info.txt", argv[1], argv[2]);
  if((info = fopen(file_string,"w"))==NULL) {
    printf("\nError while opening file [info.txt]\n");
    exit(0);
  }

  // print parameters of the simulation
  #ifdef NVT
  printf("\n**********        MC NVT-simulation        *********\n");
  fprintf(info, "\n**********        MC NVT-simulation        *********\n");
  #endif
  #ifdef NPT
  printf("\n**********        MC NPT-simulation        *********\n");
  fprintf(info, "\n**********        MC NPT-simulation        *********\n");
  #endif
  printf("\n**********  Parameters of the simulation  **********\n");
  fprintf(info, "\n**********  Parameters of the simulation  **********\n");

  printf("Simulation seed =                           %d\n", seed);
  fprintf(info, "Simulation seed =                           %d\n", seed);
  printf("Number of particles =                       %d\n", Npart);
  fprintf(info, "Number of particles =                       %d\n", Npart);
  printf("T =                                         %lg\n", T);
  fprintf(info, "T =                                         %lg\n", T);
  printf("BetaP =                                     %lg\n", betaP);
  fprintf(info, "BetaP =                                     %lg\n", betaP);
  printf("Number of MC equilibration iterations =     %llu\n", Nequilibrations);
  fprintf(info, "Number of MC equilibration iterations =     %llu\n", Nequilibrations);
  printf("Number of MC iterations in equilibrium =    %llu\n", Niterations);
  fprintf(info, "Number of MC iterations in equilibrium =    %llu\n", Niterations);
  printf("Density =                                   %lg\n", InitDensity);
  fprintf(info, "Density =                                   %lg\n", InitDensity);
  printf("Lx =                                        %lg\n", B.x);
  fprintf(info, "Lx =                                        %lg\n", B.x);
  printf("Ly =                                        %lg\n", B.y);
  fprintf(info, "Ly =                                        %lg\n", B.y);
  printf("Lz =                                        %lg\n", B.z);
  fprintf(info, "Lz =                                        %lg\n", B.z);
  printf("Maximum displacement =                      %lg\n", DeltaPos);
  fprintf(info, "Maximum displacement =                      %lg\n", DeltaPos);
  printf("Maximum volume change =                     %lg\n", DeltaL);
  fprintf(info, "Maximum volume change =                     %lg\n", DeltaL);
  printf("sigma1 =                                    %lg\n", sigma1);
  fprintf(info, "sigma1 =                                    %lg\n", sigma1);


  // Plane equilibration
  for(n=0; n<NPLANEQUILIBRATION; n++) {
    for(i=0; i<Npart; i++){
      displacement_move_plane(par, B, DeltaPos, &Nattempts_dis, &Naccepted_dis);
    }
    if(n%Nadjust==0) {
      // compute acceptance
      acceptance_dis = (double) Naccepted_dis/Nattempts_dis;
      // adjust the moves displacements
      if(acceptance_dis>(TARGET_ACC_DIS+TOL)) {
        DeltaPos *= 1.1;
      }
      else if(acceptance_dis<(TARGET_ACC_DIS-TOL)){
        DeltaPos /= 1.1;
      }
      if(DeltaPos > B.x/4) {
        DeltaPos = B.x/4;
      }
      // reset scceptances to zero
      Nattempts_dis = 0;
      Naccepted_dis = 0;
      Nattempts_vol = 0;
      Naccepted_vol = 0;
    }
  }

  // reset scceptances to zero
  Nattempts_dis = 0;
  Naccepted_dis = 0;
  Nattempts_vol = 0;
  Naccepted_vol = 0;

  // Pre-Equilibration
  sprintf(file_string, "../generation%s/sample%s/energy.dat", argv[1], argv[2]);
  if((en = fopen(file_string,"w"))==NULL) {
    printf("\nError while opening file [energy.dat]\n");
    exit(0);
  }
  #ifdef NPT
  sprintf(file_string, "../generation%s/sample%s/density.dat", argv[1], argv[2]);
  if((den = fopen(file_string,"w"))==NULL) {
    printf("\nError while opening file [density.dat]\n");
    exit(0);
  }
  #endif
  sprintf(file_string, "../generation%s/sample%s/acceptance.dat", argv[1], argv[2]);
  if((acc = fopen(file_string,"w"))==NULL) {
    printf("\nError while opening file [acceptance.dat]\n");
    exit(0);
  }
  for(n=0; n<NPREEQUILIBRATION; n++) {
    for(i=0; i<Npart; i++){
      displacement_move(par, B, DeltaPos, &Nattempts_dis, &Naccepted_dis);
    }
    for(i=0; i<Npart; i++){
      rotation_move(par, B, DeltaRot, &Nattempts_rot, &Naccepted_rot);
    }
    #ifdef NPT
    volume_move(par, &B, DeltaL, &Nattempts_vol, &Naccepted_vol);
    #endif
    if(n%Nadjust==0) {
      // compute acceptance
      acceptance_dis = (double) Naccepted_dis/Nattempts_dis;
      acceptance_rot = (double) Naccepted_rot/Nattempts_rot;
      acceptance_vol = (double) Naccepted_vol/Nattempts_vol;
      fprintf(acc, "%llu %lf %lf %lf %lf %lf %lf\n", n, DeltaPos, acceptance_dis, DeltaRot, acceptance_rot, DeltaL, acceptance_vol);
      fflush(acc);
      // adjust the moves displacements
      if(acceptance_dis>(TARGET_ACC_DIS+TOL)) {
        DeltaPos *= 1.1;
      }
      else if(acceptance_dis<(TARGET_ACC_DIS-TOL)){
        DeltaPos /= 1.1;
      }
      if(DeltaPos > B.x/4) {
        DeltaPos = B.x/4;
      }
      if(acceptance_rot>(TARGET_ACC_ROT+TOL)) {
        DeltaRot *= 1.1;
      }
      else if(acceptance_rot<(TARGET_ACC_ROT-TOL)){
        DeltaRot /= 1.1;
      }
      // if(acceptance_vol>(TARGET_ACC_VOL+TOL)) {
      //   DeltaL *= 1.05;
      // }
      // else if(acceptance_vol<(TARGET_ACC_VOL-TOL)){
      //   DeltaL /= 1.05;
      // }
      // minL = B.x;
      // if(B.y < minL) {
      //   minL = B.y;
      // }
      // if(sqrt(DeltaL) > minL/3) {
      //   DeltaL = minL*minL/9;
      // }
      // reset scceptances to zero
      Nattempts_dis = 0;
      Naccepted_dis = 0;
      Nattempts_vol = 0;
      Naccepted_vol = 0;
    }
    // if(n%Nprint==0) {
    //   #ifdef NPT
    //   density = Npart/B.V;
    //   fprintf(den, "%llu %lf\n", n, density);
    //   fflush(den);
    //   #endif
    //   energy = energy_system(par, B, scaling)/Npart;
    //   fprintf(en, "%llu %lf\n", n, energy);
    //   fflush(en);
    //   //print_snapshot(par, B, n, argv);
    // }
  }
  fclose(acc);

  // reset acceptances to zero
  Nattempts_dis = 0;
  Naccepted_dis = 0;
  Nattempts_vol = 0;
  Naccepted_vol = 0;

  // equilibration
  for(n=0; n<Nequilibrations; n++) {
    for(i=0; i<Npart; i++){
      rotodisplacement_move(par, B, DeltaPos, DeltaRot, &Nattempts_dis, &Naccepted_dis);
    }
    #ifdef NPT
    volume_move(par, &B, DeltaL, &Nattempts_vol, &Naccepted_vol);
    #endif
    if(n%Nprint==0) {
      Nmeasures += 1;
      #ifdef NVT
      av_density += InitDensity;
      #endif
      #ifdef NPT
      density = Npart/B.V;
      av_density += density;
      fprintf(den, "%llu %lf\n", n, density);
      fflush(den);
      #endif
      energy = energy_system(par, B, scaling)/Npart;
      av_energy += energy;
      fprintf(en, "%llu %lf\n", n, energy);
      fflush(en);
      // print_snapshot(par, B, n, argv);
    }
  }



  // reset scceptances to zero
  Nattempts_dis = 0;
  Naccepted_dis = 0;
  Nattempts_vol = 0;
  Naccepted_vol = 0;

  // production
  for(n=1; n<=Niterations; n++) {
    for(i=0; i<Npart; i++){
      rotodisplacement_move(par, B, DeltaPos, DeltaRot, &Nattempts_dis, &Naccepted_dis);
    }
    #ifdef NPT
    volume_move(par, &B, DeltaL, &Nattempts_vol, &Naccepted_vol);
    #endif
    if(n%Nprint==0) {
      Nmeasures += 1;
      #ifdef NVT
      av_density += InitDensity;
      #endif
      #ifdef NPT
      density = Npart/B.V;
      av_density += density;
      fprintf(den, "%llu %lf\n", n+Nequilibrations, density);
      fflush(den);
      #endif
      energy = energy_system(par, B, scaling)/Npart;
      av_energy += energy;
      fprintf(en, "%llu %lf\n", n+Nequilibrations, energy);
      fflush(en);
      print_snapshot(par, B, n, argv);
      //print_trajectory(par, B);
    }
  }
  fclose(en);
  #ifdef NPT
  fclose(den);
  #endif
  // normalize averages
  av_density /= Nmeasures;
  av_energy /= Nmeasures;
  // compute acceptance
  acceptance_dis = (double) Naccepted_dis/Nattempts_dis;
  acceptance_vol = (double) Naccepted_vol/Nattempts_vol;
  // print reslts on screen
  printf("Acceptance displacement moves   = %lg\n", acceptance_dis);
  fprintf(info, "Acceptance displacement moves   = %lg\n", acceptance_dis);
  printf("Acceptance volume moves         = %lg\n", acceptance_vol);
  fprintf(info, "Acceptance volume moves         = %lg\n", acceptance_vol);
  printf("Average energy per particle     = %lg\n", av_energy);
  fprintf(info, "Average energy per particle     = %lg\n", av_energy);
  printf("Average density                 = %lg\n", av_density);
  fprintf(info, "Average density                 = %lg\n", av_density);
  fclose(info);


  free(par);


  sprintf(file_string, "../generation%s/sample%s/flag.dat", argv[1], argv[2]);
  if((fpflag = fopen(file_string,"w"))==NULL){
    printf("ERROR: Flag did not work.\n");
    exit(0);
  }
  fprintf(fpflag, "1\n");
  fflush(fpflag);
  fclose(fpflag);

  return 0;
}



void init_param(box *b, double *DeltaPos, double *DeltaL, double *DeltaRot) {
  double Vbox, Lplane, Vplane, tempdensity, rhoplane;
  int Nplane;
  FILE *f;
  char buf[200];
  char temp[200];
  char *res;

  // open input file
  f = fopen("in.dat", "r");
  if(f==NULL) {
    printf("\nERROR: file [in.dat] not found!\n");
    exit(0);
  }
  // read input file
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %d", temp, &Npart);
  if(strcmp(temp, "Npart:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [Npart:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %lf", temp, &tempdensity);
  if(strcmp(temp, "InitDensity:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [InitDensity:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %llu", temp, &Nequilibrations);
  if(strcmp(temp, "Nequilibrations:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [Nequilibrations:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %llu", temp, &Niterations);
  if(strcmp(temp, "Niterations:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [Niterations:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %d", temp, &Nprint);
  if(strcmp(temp, "Nprint:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [Nprint:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %d", temp, &seed);
  if(strcmp(temp, "seed:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [seed:]\n", temp);
    exit(1);
  }
  // line
  res = fgets(buf, 200, f);
  sscanf(buf, "%s %d", temp, &InitConf);
  if(strcmp(temp, "InitConf:")!=0) {
    printf("ERROR: while reading input file \nfound [%s] instead of [InitConf:]\n", temp);
    exit(1);
  }
  if(InitConf > 3 || InitConf<0) {
    printf("ERROR: non-valid value for InitConf(%d)!\nMust be 0, 1, 2 or 3.\n", InitConf);
    exit(1);
  }
  fclose(f);

  // init random number generator
  if(seed == 0) {
    seed = time(0);
  }
  srand48(seed);
  // initialize box
  Vbox = Npart/InitDensity;
  b->V = Vbox;
  b->z = NLAYERS*(6.0+LAYER_SPACING);
  Vplane = Vbox/b->z;
  Nplane = (int)(Npart/NLAYERS);
  rhoplane = Nplane/Vplane;
  printf("2d density in each plane: %lf\n", rhoplane);
  if(InitConf ==2) {
    Lplane = sqrt(2.0*Vplane/sqrt(3.0));
    if(Rc>Lplane*0.5) {
      printf("\nERROR: rc larger than half of the box lenght [L = %lg]!\n", Lplane);
      printf("\n       Increase Npart or reduce density.\n");
      exit(0);
    }
    b->x = Lplane;
    b->y = Lplane*sqrt(3.0)*0.5;
  }
  // initialize cubic box
  else {
    Lplane = sqrt(Vplane);
    b->x = Lplane;
    b->y = Lplane;
  }
  *DeltaPos = 0.1;
  *DeltaRot = 0.01;
  *DeltaL = Lplane/100.0;
  beta = 1.0/T;
}


void init_rand_conf(spherocylinder *par, box b) {
  int i;
  vector scale;

  scale = setVector(1, 1, 1);
  for(i=0; i<Npart; i++) {
    // random position
    par[i].r = setVector(ran()*b.x,ran()*b.y,ran()*b.z);
    // random orientation
    par[i].q = randUnitQuaternion();
    // rod parameters
    par[i].L = 5.0;
    par[i].D = 1.0;
  }
  printf("\nInitial random configuration with %d particles succesfully generated!\n", Npart);
}

void init_smectic_conf(spherocylinder *par, box b) {
  int i, l, count, Npartlayer;
  double z, zspacing;

  if(Npart%NLAYERS != 0) {
    printf("ERROR: the number of particles is not a multiple of the number of layers (%d)!\n", NLAYERS);
    exit(0);
  }
  Npartlayer = Npart/NLAYERS;

  zspacing = 6.0 + LAYER_SPACING;
  count = 0;

  z = 3.0;
  for(l=0; l<NLAYERS; l++) {
    for(i=0; i<Npartlayer; i++) {
	    if(count<Npart) {
	      par[count].r = setVector(ran()*b.x, ran()*b.y, z);
        par[count].q = setQuaternion(1.0, 0.0, 0.0, 0.0);
        par[count].L = 5.0;
        par[count].D = 1.0;
	      count++;
      }
    }
    z += zspacing;
  }
  printf("\nInitialization of a smectic phase: %d particles placed\n", count);
}

void init_sc_conf(spherocylinder *par, box b) {
  int i, j, l, count, Nlattice, Npartlayer;
  double x, y, z, spacing, zspacing, diff;

  if(Npart%NLAYERS != 0) {
    printf("ERROR: the number of particles is not a multiple of the number of layers (%d)!\n", NLAYERS);
    exit(0);
  }
  Npartlayer = Npart/NLAYERS;

  Nlattice = sqrt(Npartlayer);
  diff = sqrt(Npartlayer) - Nlattice;
  if(diff>0.0000001) {
    Nlattice += 1;
  }
  spacing = b.x/Nlattice;
  zspacing = 6.0 + LAYER_SPACING;
  count = 0;

  z = 3.0;
  for(l=0; l<NLAYERS; l++) {
    x = 0.0;
    for(i=0; i<Nlattice; i++) {
      y = 0.0;
      for(j=0; j<Nlattice; j++) {
  	    if(count<Npart) {
  	      par[count].r = setVector(x,y,z);
          par[count].q = setQuaternion(1.0, 0.0, 0.0, 0.0);
          par[count].L = 5.0;
          par[count].D = 1.0;
  	      count++;
        }
        y += spacing;
      }
      x += spacing;
    }
    z += zspacing;
  }
  printf("\nInitialization on a sc lattice: %d particles placed\n", count);
}

void init_hex_conf(spherocylinder *par, box b) {
  int i, j, l, count, Nlattice, Npartlayer;
  double x, y, z, spacing, zspacing, sigma, diff;
  box tempb;
  vector scale;

  if(Npart%NLAYERS != 0) {
    printf("ERROR: the number of particles is not a multiple of the number of layers (%d)!\n", NLAYERS);
    exit(0);
  }
  Npartlayer = Npart/NLAYERS;

  Nlattice = sqrt(Npartlayer);
  diff = sqrt(Npartlayer) - Nlattice;
  if(diff>0.0000001) {
    Nlattice += 1;
  }
  spacing = 1.0;
  zspacing = 6.0 + LAYER_SPACING;
  sigma = 1.0;
  count = 0;

  z = 3.0;
  for(l=0; l<NLAYERS; l++) {
    for(i=0; i<Nlattice; i++) {
      for(j=0; j<Nlattice; j++) {
  	    if(count<Npart) {
          if(j%2 == 0) {
            x = i*spacing*sigma;
          }
          else {
            x = (i+0.5)*spacing*sigma;
          }
          y = j*spacing*sigma*sqrt(3.0)*0.5;
          par[count].r = setVector(x,y,z);
          par[count].q = setQuaternion(1.0, 0.0, 0.0, 0.0);
          par[count].L = 5.0;
          par[count].D = 1.0;
  	      count++;
        }
      }
    }
    z += zspacing;
  }
  tempb.x = Nlattice*spacing*sigma;
  tempb.y = Nlattice*spacing*sigma*sqrt(3.0)*0.5;
  tempb.z = b.z;
  tempb.V = tempb.x*tempb.y*tempb.z;
  // rescale particle positions
  scale = setVector(b.x/tempb.x, b.y/tempb.y, 1);
  for(i=0; i<Npart; i++) {
    par[i].r.x *= scale.x;
    par[i].r.y *= scale.y;
  }
  // rescale box
  tempb.x *= scale.x;
  tempb.y *= scale.y;
  tempb.V = tempb.x*tempb.y*tempb.z;

  printf("\nInitialization on a hexagonal lattice: %d particles placed\n", count);
}


void print_snapshot(spherocylinder *par, box b, unsigned long long int n, char ** argv) {
  int i;
  char file_name[80];
  vector u;
  FILE *out;

  sprintf(file_name, "../generation%s/sample%s/conf_%06llu.rod", argv[1], argv[2], n);
  if((out = fopen(file_name,"w"))==NULL) {
    printf("Error while opening file\n");
    exit(0);
  }
  fprintf(out,"%d\n", Npart);
  fprintf(out,"%lg %lg %lg\n", b.x, b.y, b.z);
  // fprintf(out,"0 0 0\n");
  // fprintf(out,"%lf 0 0\n", b.x);
  // fprintf(out,"0 %lf 0\n", b.y);
  // fprintf(out,"0 0 %lf\n", b.z);
  u = setVector(0.0, 0.0, 1.0);
  for(i=0; i<Npart; i++) {
    u = setVector(0.0, 0.0, 1.0);
    u = rotateVector(u, par[i].q);
    fprintf(out,"a %lf %lf %lf %lf %lf %lf 5.00 1.0\n", par[i].r.x, par[i].r.y, par[i].r.z, u.x, u.y, u.z);
  }
  fclose(out);
}

void print_trajectory(spherocylinder *par, box b) {
  int i;
  char file_name[80];
  vector u;
  FILE *out;

  sprintf(file_name, "trajectory.rod");
  if((out = fopen(file_name,"a"))==NULL) {
    printf("Error while opening file\n");
    exit(0);
  }
  fprintf(out,"%d\n", Npart);
  fprintf(out,"%lg %lg %lg\n", b.x, b.y, b.z);
  // fprintf(out,"0 0 0\n");
  // fprintf(out,"%lf 0 0\n", b.x);
  // fprintf(out,"0 %lf 0\n", b.y);
  // fprintf(out,"0 0 %lf\n", b.z);
  u = setVector(0.0, 0.0, 1.0);
  for(i=0; i<Npart; i++) {
    u = setVector(0.0, 0.0, 1.0);
    u = rotateVector(u, par[i].q);
    fprintf(out,"a %lf %lf %lf %lf %lf %lf 5.00 1.0\n", par[i].r.x, par[i].r.y, par[i].r.z, u.x, u.y, u.z);
  }
  fclose(out);
}


/*void volume_move(vector *par, box *b, double DeltaL, unsigned long long int *Nattempts, unsigned long long int *Naccepted) {
  double gamma, ratio, newV, newVolumaccio;
  vector scalen, scaleo;
  int i;
  double eno, enn;
  double r, p;


  *Nattempts += 1;
  // random change of volume
  newVolumaccio = b->V + DeltaL*(ran()-0.5);
  ratio = b->x/b->y;
  //printf("ratio is: %lf\n", ratio);
  gamma = newVolumaccio/b->V;
  scalen = setVector(pow(gamma,0.5), pow(gamma,0.5), 1);
  // compute new volume
  newV = scalen.x*b->x*scalen.y*b->y*scalen.z*b->z;
  if(fabs(newV-newVolumaccio)>0.001){
    printf("ERROR! VOLUMACCIO PROBLEM");
  }
  // energy of old configuration
  scaleo = setVector(1, 1, 1);
  eno = 0.0;
  for(i=0; i<Npart; i++) {
    //printf("newV = %lf, oldV = %lf, calculating old energy...\n", newV, b->V);
    eno += energy_particle(par[i], i, par, *b, scaleo, i+1);
  }
  // energy of new configuration
  enn = 0.0;
  for(i=0; i<Npart; i++) {
    //printf("newV = %lf, oldV = %lf, calculating new energy...\n", newV, b->V);
    enn += energy_particle(par[i], i, par, *b, scalen, i+1);
  }
  r = ran();
  p = exp(-beta*(enn-eno)-betaP*(newV-b->V))*pow(newV/b->V, Npart);
  if(r<p) {
    // accept
    *Naccepted += 1;
    // update positions and volume
    rescale(par, b, scalen, newV);
  }
}*/


void displacement_move(spherocylinder *par, box b, double DeltaPos, unsigned long long int *Nattempts, unsigned long long int *Naccepted) {
  vector dr, scale;
  spherocylinder newpar;
  double eno, enn, r, p;
  int i;

  //printf("Displacement move!!!");
  *Nattempts += 1;
  // pick a particle at random
  i = lrand48() % Npart;
  // random displacement
  dr = setVector((ran()-0.5)*DeltaPos,(ran()-0.5)*DeltaPos,(ran()-0.5)*DeltaPos);
  newpar.r = sumVectors(par[i].r, dr);
  // same orientation
  newpar.q = par[i].q;
  // copy other parameters
  newpar.L = par[i].L;
  newpar.D = par[i].D;
  // setting new volume equal to old volume
  scale = setVector(1, 1, 1);
  // energy of new configuration
  enn = energy_particle(newpar, i, par, b, scale, 0);
  // energy of old configuration
  eno = energy_particle(par[i], i, par, b, scale, 0);
  //metropolis check
  r = ran();
  p = exp(-beta*(enn-eno));
  if(r<p) {
    //accept
    *Naccepted += 1;
    // put particle in simulation box
    if(newpar.r.x < 0.0)
      newpar.r.x += b.x;
    else if(newpar.r.x >= b.x)
      newpar.r.x-=b.x;

    if(newpar.r.y < 0.0)
      newpar.r.y += b.y;
    else if(newpar.r.y >= b.y)
      newpar.r.y -= b.y;

    if(newpar.r.z < 0.0)
      newpar.r.z += b.z;
    else if(newpar.r.z >= b.z)
      newpar.r.z -= b.z;
    //update new position and orientation
    par[i].r = newpar.r;
    par[i].q = newpar.q;
  }
}

void displacement_move_plane(spherocylinder *par, box b, double DeltaPos, unsigned long long int *Nattempts, unsigned long long int *Naccepted) {
  vector dr, scale;
  spherocylinder newpar;
  double eno, enn, r, p;
  int i;

  //printf("Displacement move!!!");
  *Nattempts += 1;
  // pick a particle at random
  i = lrand48() % Npart;
  // random displacement
  dr = setVector((ran()-0.5)*DeltaPos,(ran()-0.5)*DeltaPos,0.0);
  newpar.r = sumVectors(par[i].r, dr);
  // same orientation
  newpar.q = par[i].q;
  // copy other parameters
  newpar.L = par[i].L;
  newpar.D = par[i].D;
  // setting new volume equal to old volume
  scale = setVector(1, 1, 1);
  // energy of new configuration
  enn = energy_particle(newpar, i, par, b, scale, 0);
  // energy of old configuration
  eno = energy_particle(par[i], i, par, b, scale, 0);
  //metropolis check
  r = ran();
  p = exp(-beta*(enn-eno));
  if(r<p) {
    //accept
    *Naccepted += 1;
    // put particle in simulation box
    if(newpar.r.x < 0.0)
      newpar.r.x += b.x;
    else if(newpar.r.x >= b.x)
      newpar.r.x-=b.x;

    if(newpar.r.y < 0.0)
      newpar.r.y += b.y;
    else if(newpar.r.y >= b.y)
      newpar.r.y -= b.y;

    if(newpar.r.z < 0.0)
      newpar.r.z += b.z;
    else if(newpar.r.z >= b.z)
      newpar.r.z -= b.z;
    //update new position and orientation
    par[i].r = newpar.r;
    par[i].q = newpar.q;
  }
}

void rotation_move(spherocylinder *par, box b, double DeltaRot, unsigned long long int *Nattempts, unsigned long long int *Naccepted) {
  vector scale;
  quaternion dq;
  spherocylinder newpar;
  double eno, enn, r, p;
  int i;

  //printf("Displacement move!!!");
  *Nattempts += 1;
  // pick a particle at random
  i = lrand48() % Npart;
  // seme position
  newpar.r = par[i].r;
  // random rotation
  dq = multiplyQuaternion(DeltaRot, randUnitQuaternion());
  newpar.q = normalizeQuaternion(sumQuaternions(par[i].q, dq));
  // copy other parameters
  newpar.L = par[i].L;
  newpar.D = par[i].D;
  // setting new volume equal to old volume
  scale = setVector(1, 1, 1);
  // energy of new configuration
  enn = energy_particle(newpar, i, par, b, scale, 0);
  // energy of old configuration
  eno = energy_particle(par[i], i, par, b, scale, 0);
  // metropolis check
  r = ran();
  p = exp(-beta*(enn-eno));
  if(r<p) {
    // accept
    *Naccepted += 1;
    // update new orientation
    par[i].q = newpar.q;
  }
}

void rotodisplacement_move(spherocylinder *par, box b, double DeltaPos, double DeltaRot, unsigned long long int *Nattempts, unsigned long long int *Naccepted) {
  vector dr, scale;
  quaternion dq;
  spherocylinder newpar;
  double eno, enn, r, p;
  int i;

  //printf("Displacement move!!!");
  *Nattempts += 1;
  // pick a particle at random
  i = lrand48() % Npart;
  // random displacement
  dr = setVector((ran()-0.5)*DeltaPos,(ran()-0.5)*DeltaPos,(ran()-0.5)*DeltaPos);
  newpar.r = sumVectors(par[i].r, dr);
  // random rotation
  dq = multiplyQuaternion(DeltaRot, randUnitQuaternion());
  newpar.q = normalizeQuaternion(sumQuaternions(par[i].q, dq));
  // copy other parameters
  newpar.L = par[i].L;
  newpar.D = par[i].D;
  // setting new volume equal to old volume
  scale = setVector(1, 1, 1);
  // energy of new configuration
  enn = energy_particle(newpar, i, par, b, scale, 0);
  // energy of old configuration
  eno = energy_particle(par[i], i, par, b, scale, 0);
  //metropolis check
  r = ran();
  p = exp(-beta*(enn-eno));
  if(r<p) {
    //accept
    *Naccepted += 1;
    // put particle in simulation box
    if(newpar.r.x < 0.0)
      newpar.r.x += b.x;
    else if(newpar.r.x >= b.x)
      newpar.r.x-=b.x;

    if(newpar.r.y < 0.0)
      newpar.r.y += b.y;
    else if(newpar.r.y >= b.y)
      newpar.r.y -= b.y;

    if(newpar.r.z < 0.0)
      newpar.r.z += b.z;
    else if(newpar.r.z >= b.z)
      newpar.r.z -= b.z;
    //update new position and orientation
    par[i].r = newpar.r;
    par[i].q = newpar.q;
  }
}

void rescale(spherocylinder *par, box *b, vector scaling, double newV) {
  int i;

  // rescale particle positions
  for(i=0; i<Npart; i++) {
    par[i].r.x *= scaling.x;
    par[i].r.y *= scaling.y;
    par[i].r.z *= scaling.z;
  }
  // rescale box
  b->V = newV;
  b->x *= scaling.x;
  b->y *= scaling.y;
  b->z *= scaling.z;
}

double minimumDistance(vector rij, vector ui, vector uj, double Li, double Lj) {
  double uiuj, Delta;
  vector uplus, uminus, uorth;
  vector rorth;
  vector Ai, Bi, Aj, Bj, extremedistance;
  double extremesquaredsdistance;
  double lambda0, mu0;
  double a, b, c, d;
  double gammamin, deltamin;
  double gamma0, delta0;
  double orthsquareddistance, parallelsquareddistance, squareddistance;

  uiuj = dotProduct(ui, uj);
  Delta = 1. - (uiuj * uiuj);
  if(Delta < (-1. * PARALLELISM_TRESHOLD)) {
    //Delta cannot be negative
    printf("ERROR! Delta is negative!\nProgram will be arrested.\n");
    exit(EXIT_FAILURE);
  }
  else if(Delta <= PARALLELISM_TRESHOLD) {
    //PARALLEL SEGMENTS
    parallelsquareddistance = dotProduct(rij, ui) * dotProduct(rij, ui);
    orthsquareddistance = dotProduct(rij, rij)-parallelsquareddistance;
    if(parallelsquareddistance < (0.5*(Li+Lj))*(0.5*(Li+Lj))) {
      squareddistance = orthsquareddistance;
    }
    else {
      Ai = multiplyVector(0.5*Li, ui);
      Bi = multiplyVector(-0.5*Li, ui);
      Aj = sumVectors(rij, multiplyVector(0.5*Lj, uj));
      Bj = sumVectors(rij, multiplyVector(-0.5*Lj, uj));


      extremedistance = sumVectors(Aj, oppositeVector(Ai));
      squareddistance = dotProduct(extremedistance, extremedistance);
      extremedistance = sumVectors(Bj, oppositeVector(Ai));
      extremesquaredsdistance = dotProduct(extremedistance, extremedistance);
      if(extremesquaredsdistance<squareddistance) {
        squareddistance = extremesquaredsdistance;
      }
      extremedistance = sumVectors(Aj, oppositeVector(Bi));
      extremesquaredsdistance = dotProduct(extremedistance, extremedistance);
      if(extremesquaredsdistance<squareddistance) {
        squareddistance = extremesquaredsdistance;
      }
      extremedistance = sumVectors(Bj, oppositeVector(Bi));
      extremesquaredsdistance = dotProduct(extremedistance, extremedistance);
      if(extremesquaredsdistance<squareddistance) {
        squareddistance = extremesquaredsdistance;
      }
    }
    return sqrt(squareddistance);
  }
  else {
    //NON-PARALLEL SEGMENTS
    //First of all, determine the part of the distance vector rij orthogonal to both the segments
    uplus = multiplyVector((1 / sqrt(2 * (1 + uiuj))), sumVectors(ui, uj));
    uminus = multiplyVector((1 / sqrt(2 * (1 - uiuj))), sumVectors(ui, oppositeVector(uj)));
    uorth = crossProduct(uplus, uminus);
    rorth = multiplyVector(dotProduct(rij, uorth), uorth);
    //And compute the orthogonal squared distance
    orthsquareddistance = dotProduct(rorth, rorth);


    //Now, we still have to take care of the in-plane distance (if non-null)
    //First of all, determine lambda0 and mu0
    lambda0 = (-1. * dotProduct(ui, rij) + uiuj * dotProduct(uj, rij)) / Delta;
    mu0 = (dotProduct(uj, rij) - uiuj * dotProduct(ui, rij)) / Delta;

    if((fabs(lambda0) <= (0.5 * Li)) && (fabs(mu0) <= (0.5 * Lj)))
    {
      //The in-plane distance between the segments' projections is zero, and the orthogonal one is the whole distance
      return sqrt(orthsquareddistance);
    }

    //Otherwise, we have to compute the in-plane distance
    //First of all, we have to determine gammamin and deltamin
    //They are the values closest to the origin in the intervals [a,b] and [c,d] respectively, where
    a = -1. * lambda0 - 0.5 * Li;
    b = -1. * lambda0 + 0.5 * Li;
    c = -1. * mu0 - 0.5 * Lj;
    d = -1. * mu0 + 0.5 * Lj;

    //Thus, for gammamin
    if((a * b) <= 0)
    {
      gammamin = 0.;
    }
    else if(a < 0)
    {
      gammamin = b;
    }
    else
    {
      gammamin = a;
    }

    //While, for deltamin
    if((c * d) <= 0)
    {
      deltamin = 0.;
    }
    else if(c < 0)
    {
      deltamin = d;
    }
    else
    {
      deltamin = c;
    }


    //Now we can effectively locate the points of minimum distance between the line segments
    //Let's first consider the case of |gammamin| >= |deltamin|
    if(fabs(gammamin) >= fabs(deltamin))
    {
      gamma0 = gammamin;

      //If gamma0 * uiuj is an allowed value for delta, we choose it as delta0, otherwise we choose the closest allowed value
      delta0 = gamma0 * uiuj;

      if(fabs(delta0 + mu0) > (0.5 * Lj))
      {
        if(delta0 < c)
        {
          delta0 = c;
        }
        else if(delta0 > d)
        {
          delta0 = d;
        }
        else
        {
          printf("Error, a case not considered in determining delta0.\nProgram will be arrested.\n");
          exit(EXIT_FAILURE);
        }
      }
    }

    //And then let's consider the case of |gammamin| < |deltamin|
    else
    {
      delta0 = deltamin;

      //If delta0 * uiuj is an allowed value for gamma, we choose it as gamma0, otherwise we choose the closest allowed value
      gamma0 = delta0 * uiuj;

      if(fabs(gamma0 + lambda0) > (0.5 * Li))
      {
        if(gamma0 < a)
        {
          gamma0 = a;
        }
        else if(gamma0 > b)
        {
          gamma0 = b;
        }
        else
        {
          printf("Error, a case not considered in determining gamma0.\nProgram will be arrested.\n");
          exit(EXIT_FAILURE);
        }
      }
    }


    //Now that we have gamma0 and delta0 we can compute the in-plane minimum squared distance as
    parallelsquareddistance = (gamma0 * gamma0) + (delta0 * delta0) - 2 * gamma0 * delta0 * uiuj;
    //And thus the complete squared distance as
    squareddistance = orthsquareddistance + parallelsquareddistance;

    return sqrt(squareddistance);
  }
}


double pair_energy(spherocylinder s1, spherocylinder s2, box b, vector scaling) {
  double energy, r, dmin;
  vector d, u, u1, u2;

  // center-center distance
  d.x = scaling.x*s2.r.x - scaling.x*s1.r.x;
  d.y = scaling.y*s2.r.y - scaling.y*s1.r.y;
  d.z = scaling.z*s2.r.z - scaling.z*s1.r.z;
  // periodic boundary conditions
  d = pbc(d, b, scaling);
  // radial distance
  r = sqrt(dotProduct(d,d));

  // filter rods which are too distant to interact
  if(r >= 0.5*(s1.L+s2.L)+Rc) {
    return 0.0;
  }

  // orientation vectors
  u = setVector(0.,0.,1.);
  u1 = rotateVector(u, s1.q);
  u2 = rotateVector(u, s2.q);

  // minimum distance
  dmin = minimumDistance(d, u1, u2, s1.L, s2.L);

  // energy
  energy = 0.0;
  if(dmin<Rc) {
    energy = epsilon*(pow(1./dmin, 14) + 0.5*(1.-tanh(kappa*(dmin-sigma1))));
  }
  return energy;
}


double energy_particle(spherocylinder newpar, int i, spherocylinder *par, box b, vector scaling, int k) {
  int j;
  double energy, ctenergy;

  energy = 0.0;
  ctenergy = epsilon*(pow(1./Rc, 14) + 0.5*(1.-tanh(kappa*(Rc-sigma1))));
  for(j=k; j<Npart; j++) {
    if(j != i) {
      energy += pair_energy(newpar, par[j], b, scaling)-ctenergy;
    }
  }
  return energy;
}




// sampling

double energy_system(spherocylinder *par, box b, vector scaling) {
  int i;
  double energy;

  energy = 0.0;
  for(i=0; i<Npart; i++){
    energy += energy_particle(par[i], i, par, b, scaling, i+1);
  }
  return energy;
}


// vectors

vector pbc(vector dist, box b, vector scaling) {
  vector d;
  // apply periodic boundary conditions
  d.x = dist.x - b.x*scaling.x*rint(dist.x/(b.x*scaling.x));
  d.y = dist.y - b.y*scaling.y*rint(dist.y/(b.y*scaling.y));
  d.z = dist.z - b.z*scaling.z*rint(dist.z/(b.z*scaling.z));

  return d;
}

double ran() {
  double r;
  // random number in (0,1)
  r = (double) lrand48()/RAND_MAX;
  return r;
}

vector setVector(double x, double y, double z) {
  vector result;
  result.x = x;
  result.y = y;
  result.z = z;
  return result;
}

vector sumVectors(vector a, vector b) {
  vector result;
  result.x = a.x + b.x;
  result.y = a.y + b.y;
  result.z = a.z + b.z;
  return result;
}

vector distanceVector(vector a, vector b) {
  vector d;
  // distance a-b
  d.x = a.x-b.x;
  d.y = a.y-b.y;
  d.z = a.z-b.z;
  return d;
}

double dotProduct(vector a, vector b) {
  double dot;
  dot = a.x*b.x + a.y*b.y + a.z*b.z;
  return dot;
}

vector multiplyVector(double s, vector u) {
  vector result;
  result.x = s * u.x;
  result.y = s * u.y;
  result.z = s * u.z;
  return result;
}

vector oppositeVector(vector u) {
  vector result;
  result.x = -1. * u.x;
  result.y = -1. * u.y;
  result.z = -1. * u.z;
  return result;
}

vector crossProduct(vector u, vector v) {
  vector result;
  result.x = u.y * v.z - u.z * v.y;
  result.y = u.z * v.x - u.x * v.z;
  result.z = u.x * v.y - u.y * v.x;
  return result;
}

quaternion conjugateQuaternion(quaternion q) {
  quaternion result;
  result.t = q.t;
  result.x = -q.x;
  result.y = -q.y;
  result.z = -q.z;
  return result;
}

quaternion normalizeQuaternion(quaternion q) {
  double norm;
  quaternion result;
  norm = sqrt(q.t*q.t + q.x*q.x + q.y*q.y + q.z*q.z);
  result.t = q.t/norm;
  result.x = q.x/norm;
  result.y = q.y/norm;
  result.z = q.z/norm;
  return result;
}

vector normalizeVector(vector q) {
  double norm;
  vector result;
  norm = sqrt(q.x*q.x + q.y*q.y + q.z*q.z);
  result.x = q.x/norm;
  result.y = q.y/norm;
  result.z = q.z/norm;
  return result;
}

quaternion setQuaternion(double t, double x, double y, double z) {
  quaternion result;
  result.t = t;
  result.x = x;
  result.y = y;
  result.z = z;
  return result;
}

quaternion setRotation(vector axis, double angle) {
  /* function that returns the quaternion defining
  a rotation along a given axis of a given angle */
  quaternion result;
  double t, x, y, z;
  t = cos(angle*0.5);
  x = axis.x*sin(angle*0.5);
  y = axis.y*sin(angle*0.5);
  z = axis.z*sin(angle*0.5);
  result = setQuaternion(t,x,y,z);
  return result;
}


quaternion sumQuaternions(quaternion a, quaternion b) {
  quaternion result;
  result.t = a.t + b.t;
  result.x = a.x + b.x;
  result.y = a.y + b.y;
  result.z = a.z + b.z;
  return result;
}



double vectorNorm(vector v) {
  double norm;
  norm = sqrt(dotProduct(v,v));
  return norm;
}


vector applyMatrixToVector(double A[3][3], vector v) {
  vector result;
  result.x = A[0][0]*v.x + A[0][1]*v.y + A[0][2]*v.z;
  result.y = A[1][0]*v.x + A[1][1]*v.y + A[1][2]*v.z;
  result.z = A[2][0]*v.x + A[2][1]*v.y + A[2][2]*v.z;
  return result;
}

double matrixDeterminant(double A[3][3]) {
  vector a, b, c;
  double det;
  a.x = A[0][0];
  a.y = A[1][0];
  a.z = A[2][0];

  b.x = A[0][1];
  b.y = A[1][1];
  b.z = A[2][1];

  c.x = A[0][2];
  c.y = A[1][2];
  c.z = A[2][2];

  det = dotProduct(a, crossProduct(b, c));
  return det;
}

void transposeMatrix(double Q[3][3], double QT[3][3]) {
  int i, j;
  for(i=0; i<3; i++) {
    for(j=0; j<3; j++) {
      QT[i][j] = Q[j][i];
    }
  }
}

void invertMatrix(double Q[3][3], double invQ[3][3]) {
  int i, j;
  double detQ;
  double mQ[3][3];
  // compute det(Q)
  detQ = matrixDeterminant(Q);
  // build the matrix of minors
  for(i=0; i<3; i++) {
    for(j=0; j<3; j++) {
      //Compute the matrix of minors
      mQ[i][j] = Q[(i+1)%3][(j+1)%3]*Q[(i+2)%3][(j+2)%3] - Q[(i+1)%3][(j+2)%3]*Q[(i+2)%3][(j+1)%3];
    }
  }
  //The inverse matrix is the transpose of the matrix of minors
  transposeMatrix(mQ, invQ);
  //With each element divided by the determinant of Q
  for(i=0; i<3; i++) {
    for(j=0; j<3; j++) {
      invQ[i][j] /= detQ;
    }
  }
}

quaternion multiplyQuaternion(double lambda, quaternion q) {
  quaternion result;
  result.t = lambda*q.t;
  result.x = lambda*q.x;
  result.y = lambda*q.y;
  result.z = lambda*q.z;
  return result;
}

quaternion HamiltonProduct(quaternion a, quaternion b) {
  quaternion result;
  result.t = a.t*b.t - a.x*b.x - a.y*b.y - a.z*b.z;
  result.x = a.t*b.x + a.x*b.t + a.y*b.z - a.z*b.y;
  result.y = a.t*b.y - a.x*b.z + a.y*b.t + a.z*b.x;
  result.z = a.t*b.z + a.x*b.y - a.y*b.x + a.z*b.t;
  return result;
}


vector randUnitVector() {
  vector result;
  double ran1, ran2, ransq, ranh;
  do {
    ran1 = 1.0-2.0*ran();
    ran2 = 1.0-2.0*ran();
    ransq = ran1*ran1 + ran2*ran2;
  } while(ransq >= 1.0);
  ranh = 2.0*sqrt(1.0-ransq);
  result.x = ran1*ranh;
  result.y = ran2*ranh;
  result.z = (1.0-2.0*ransq);
  return result;
}

quaternion randUnitQuaternion() {
  quaternion result;
  double ran1, ran2, ran3, ran4, s1, s2, ranh;
  do {
    ran1 = 1.0-2.0*ran();
    ran2 = 1.0-2.0*ran();
    s1 = ran1*ran1 + ran2*ran2;
  } while(s1 >= 1.0);
  do {
    ran3 = 1.0-2.0*ran();
    ran4 = 1.0-2.0*ran();
    s2 = ran3*ran3 + ran4*ran4;
  } while(s2 >= 1.0);
  ranh = sqrt((1.0-s1)/s2);
  result.t = ran1;
  result.x = ran2;
  result.y = ran3*ranh;
  result.z = ran4*ranh;
  return result;
}

vector rotateVector(vector u, quaternion q) {
  /* function to rotate vector u with rotation
  defined by quaternion q */
  quaternion p, prot;
  vector urot;
  // build quaternion p from vector u
  p = setQuaternion(0.0, u.x, u.y, u.z);
  // rotate p
  prot = HamiltonProduct(p,conjugateQuaternion(q));
  prot = HamiltonProduct(q,prot);
  // build rotated vector
  urot = setVector(prot.x, prot.y, prot.z);
  return urot;
}
