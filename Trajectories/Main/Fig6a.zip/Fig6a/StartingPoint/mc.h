#define NVT
#define TARGET_ACC_VOL 0.20
#define TARGET_ACC_DIS 0.5
#define TARGET_ACC_ROT 0.5
#define TOL 0.05
#define PARALLELISM_TRESHOLD 0.000001
#define LAYER_SPACING 0.5
#define NLAYERS 3
#define NPREEQUILIBRATION 5000
#define NPLANEQUILIBRATION 50000


#define epsilon 1.0
#define kappa 10.0
#define Rc 3.0
#define Nadjust 100

/************** STRUCTS ******************/
typedef struct {
  double x;
  double y;
  double z;
} vector;

typedef struct {
  double x;
  double y;
  double z;
  double V;
} box;

typedef struct {
  double x;
  double y;
  double z;
  double r;
  int id;
} neighbor;

typedef struct {
  double Re;
  double Im;
} complexnumber;

typedef struct {
  int x;
  int y;
  int z;
} intvector;

typedef struct {
  double t;
  double x;
  double y;
  double z;
} quaternion;

typedef struct {
  double d;
  vector r;
} sphere;


typedef struct {
  double L;
  double D;
  vector r;
  quaternion q;
} spherocylinder;

/*************** FUNCTIONS ***************/
void init_param(box *b, double *DeltaPos, double *DeltaL, double *Dr);
void init_rand_conf(spherocylinder *par, box b);
void init_smectic_conf(spherocylinder *par, box b);
void init_sc_conf(spherocylinder *par, box b);
void init_hex_conf(spherocylinder *par, box b);
void print_snapshot(spherocylinder *par, box b, unsigned long long int n, char ** argv);
void print_trajectory(spherocylinder *par, box b);
void volume_move(vector *par, box *b, double DeltaL, unsigned long long int *Nattempts, unsigned long long int *Naccepted);
void displacement_move(spherocylinder *par, box b, double DeltaPos, unsigned long long int *Nattempts, unsigned long long int *Naccepted);
void displacement_move_plane(spherocylinder *par, box b, double DeltaPos, unsigned long long int *Nattempts, unsigned long long int *Naccepted);
void rotation_move(spherocylinder *par, box b, double DeltaRot, unsigned long long int *Nattempts, unsigned long long int *Naccepted);
void rotodisplacement_move(spherocylinder *par, box b, double DeltaPos, double DeltaRot, unsigned long long int *Nattempts, unsigned long long int *Naccepted);
void rescale(spherocylinder *par, box *b, vector scaling, double newV);
double energy_particle(spherocylinder newpar, int i, spherocylinder *par, box b, vector scaling, int k);
vector pbc(vector dist, box b, vector scaling);
double ran();
// sampling
double energy_system(spherocylinder *par, box b, vector scaling);
// vectors
vector setVector(double x, double y, double z);
vector sumVectors(vector a, vector b);
vector distanceVector(vector a, vector b);
double dotProduct(vector a, vector b);
vector multiplyVector(double s, vector u);
vector oppositeVector(vector u);
vector crossProduct(vector u, vector v);
quaternion conjugateQuaternion(quaternion q);
quaternion normalizeQuaternion(quaternion q);
quaternion setQuaternion(double t, double x, double y, double z);
quaternion setRotation(vector axis, double angle);
quaternion sumQuaternions(quaternion a, quaternion b);
double vectorNorm(vector v);
vector applyMatrixToVector(double A[3][3], vector v);
double matrixDeterminant(double A[3][3]);
void transposeMatrix(double Q[3][3], double QT[3][3]);
void invertMatrix(double Q[3][3], double invQ[3][3]);
quaternion multiplyQuaternion(double lambda, quaternion q);
quaternion HamiltonProduct(quaternion a, quaternion b);
vector randUnitVector();
quaternion randUnitQuaternion();
vector rotateVector(vector u, quaternion q);
// rods
double minimumDistance(vector rij, vector ui, vector uj, double Li, double Lj);
double pair_energy(spherocylinder s1, spherocylinder s2, box b, vector scaling);

/*************** GLOBAL VARIABLES ***************/
int Npart, seed;
double sigma1;
double betaP=1.0, InitDensity, beta, T;
unsigned long long int Niterations, Nequilibrations;
int Nprint;
double lambda;
int InitConf;
