import linecache
import numpy as np
import math
import sys

nGen = int(sys.argv[1])
line1row = 3
line2row = 4
line3row = 5
lineSigma = 9

fileOut = open('covariance.dat', 'w')
for currentG in [str(g+1).zfill(3) for g in range(nGen)]:
	fileIn = 'generation' + currentG + '/param_gauss.dat'
	sigma = float(linecache.getline(fileIn, lineSigma))
	firstRow = [float(n) for n in linecache.getline(fileIn, line1row).split()]
	secondRow = [float(n) for n in linecache.getline(fileIn, line2row).split()]
	thirdRow = [float(n) for n in linecache.getline(fileIn, line3row).split()]
	fileOut.write(str(firstRow[0]*(sigma**2)) + ' ' + str(firstRow[1]*(sigma**2)) + ' ' + str(firstRow[2]*(sigma**2)) + ' ' + str(secondRow[0]*(sigma**2)) + ' ' + str(secondRow[1]*(sigma**2)) + ' ' + str(secondRow[2]*(sigma**2)) + ' ' + str(thirdRow[0]*(sigma**2)) + ' ' + str(thirdRow[1]*(sigma**2)) + ' ' + str(thirdRow[2]*(sigma**2)) + '\n')
fileOut.close()
