import sys
import math
import linecache
import numpy as np
from scipy import linalg

DIM = 3
nSamples = 20
miSamples = 8

data = []
fitness = []
weights = nSamples*[0.]

new_generation = sys.argv[1]
next_generation = float(new_generation)
current_generation = int(next_generation - 1)

Lowest = [0.05,5.0,1.0]
Highest = [0.35,60.0,2.0]


#for su tutti i sample
for i in range(nSamples):
	file_name_siminfo = '../generation' + str(current_generation).zfill(3) +'/sample' + str(i) + '/siminfo.dat'
	file_name_fitness = '../generation' + str(current_generation).zfill(3) +'/sample' + str(i) + '/fitness.dat'
	features = (linecache.getline(file_name_siminfo, 1)).split()
	for j in range(len(features)):
		features[j] = float(features[j])
	fitness_value = float(linecache.getline(file_name_fitness, 1))
	data.append((features[0],features[1],features[2]))
	fitness.append(fitness_value)


#vedo chi so i meglio e li ordino avendo il match tra il rank e i parametri k, eps e p
for i in range(nSamples):
	for j in range(nSamples):
		if fitness[j] <= fitness[i]:
			weights[i] += 1.
	if weights[i] > miSamples:
		weights[i] = 0.;
	else :
		weights[i] = math.log(miSamples+1) - math.log(weights[i])

### SET EMPIRICAL PARAMETERS FOR CMA-ES ###
print('\n')
weights = np.array(weights)
weights *= 1/(np.sum(weights))
weights = list(weights)
for i in range(nSamples):
	print('Sample ' + str(i) + ' with parameters ' + str(data[i][0]) + ', ' + str(data[i][1]) + ', ' + str(data[i][2]) +' has been given a weight equal to ' + str(weights[i]))
print('\n\n')

mi_eff = 0
for i in range(nSamples):
	if weights[i] > 0:
		mi_eff += weights[i]**2
mi_eff = 1./mi_eff
#print('mi_eff is ' + str(mi_eff) + '\n')

c_sigma = (mi_eff + 2.)/(DIM + mi_eff + 3.)
#print('c_sigma is ' + str(c_sigma) + '\n')

if ( ((mi_eff-1.)/(DIM+1.))**0.5 - 1 ) > 0 :
	d_sigma = 1 + 2.*( ((mi_eff-1.)/(DIM+1.))**0.5 - 1 ) + c_sigma 
else :
	d_sigma = 1 + c_sigma
#print('d_sigma is ' + str(d_sigma) + '\n')

cc = 4./(DIM + 4.)
#print('cc is ' + str(cc) + '\n')

mi_cov = mi_eff
#print('mi_cov is ' + str(mi_cov) + '\n')

if ( (2.*mi_eff-1.)/((DIM + 2.)**2+mi_eff) ) < 1 :
	c_cov =  (2.)/(mi_cov*((DIM + 2**0.5)**2)) + (1 - 1./mi_cov)*( (2.*mi_eff-1.)/((DIM + 2.)**2+mi_eff) )
else :
	c_cov = c_cov =  (2.)/(mi_cov*((DIM + 2**0.5)**2)) + (1 - 1./mi_cov)
#print('c_cov is ' + str(c_cov) + '\n')

#leggo da file quali sono i parametri della gaussiana
mu = DIM*[0.]
cov = []
q = DIM*[0.]
sigma = 0.
p = DIM*[0.]


gauss_file_read = '../generation' + str(current_generation).zfill(3) +'/param_gauss.dat'
line_mu = 1
line_cov = line_mu + 2
line_q = line_cov + DIM + 1
line_sigma = line_q + 2
line_p = line_sigma + 2

features = (linecache.getline(gauss_file_read, line_mu)).split()
for j in range(len(features)):
	mu[j] = float(features[j])
mu = np.array(mu)

for i in range(DIM):
	features = (linecache.getline(gauss_file_read, line_cov + i)).split()
	for j in range(len(features)):
		cov.append(float(features[j]))
cov = np.array(cov)

features = (linecache.getline(gauss_file_read, line_q)).split()
for j in range(len(features)):
	q[j] = float(features[j])
q = np.array(q)

features = linecache.getline(gauss_file_read, line_sigma)
sigma = float(features)

features = (linecache.getline(gauss_file_read, line_p)).split()
for j in range(len(features)):
	p[j] = float(features[j])
p = np.array(p)

#utilizzo le equazioni CMA per evolverli
c1 = 0.2
c2 = 0.2
c3 = 0.2
c4 = 0.2
c5 = 0.2
c6 = 0.2
c7 = 0.2

#s_mean = 0
#for i in range(1000000):
	#s = np.random.normal(0., 1., 3)
	#s = s*s
	#s = (np.sum(s))
	#s_mean += s
#s_mean /= 1000000
#print(s_mean)

new_mu = np.copy(mu)
new_cov = np.copy(cov)
new_q = np.copy(mu)
new_sigma = sigma
new_p = np.copy(p)

sigmona = new_cov.reshape(DIM,DIM)*sigma*sigma
inv_sigmona = np.linalg.inv(sigmona)
sqrtinv_simgona = linalg.sqrtm(inv_sigmona)
#print(sqrtinv_simgona.real[1][0])

for i in range(DIM):
	for j in range(nSamples):
		new_mu[i] += weights[j]*(data[j][i] - mu[i]) 

for i in range(DIM):
	new_q[i] = (1.-c_sigma)*q[i]
	for j in range(DIM):
		new_q[i] += ((c_sigma*mi_eff*(2. - c_sigma))**0.5)*sqrtinv_simgona.real[i][j]*(new_mu[j] - mu[j])


h = (  (((math.sqrt(np.sum(new_q**2))))/(math.sqrt(1. - (1 - c_sigma)**(2*(next_generation+1.)))) )  <  ((1.5 + (1./(DIM-0.5)))*math.sqrt(DIM))  )
h = int(h)
h = float(h)
delta_h = cc*(2.-cc)*(1.-h)
#print(h)
#print(delta_h)


for i in range(DIM):
	new_p[i] = (1-cc)*p[i] + h*((cc*mi_eff*(2. - cc))**0.5)*((new_mu[i] - mu[i])/new_sigma)

for i in range(DIM):
	for j in range(DIM):
		new_cov[i*DIM+j] = (1 - c_cov + delta_h*c_cov/mi_cov)*cov[i*DIM+j] + (c_cov/mi_cov)*new_p[i]*new_p[j]
		for k in range(nSamples):
			new_cov[i*DIM+j] += c_cov*(1. - 1./mi_cov)*weights[k]*(((data[k][i]-mu[i])/new_sigma)*((data[k][j]-mu[j])/new_sigma))

new_sigma = sigma*math.exp(0.1*(c_sigma/d_sigma)*(((math.sqrt(np.sum(new_q**2)))/(math.sqrt(DIM)))-1))


#scrivo su un file della prossima cartella generation i nuovi parametri della gaussiana

filepath = '../generation' + new_generation + '/'

gauss_file = filepath + 'param_gauss.dat'
fgauss = open(gauss_file, 'w')

MeanValues = np.empty(DIM)
Cov = np.zeros(DIM**2).reshape(DIM,DIM)

for i in range(DIM):
	MeanValues[i] = new_mu[i]
	for j in range(DIM):
		Cov[i][j] = new_cov[i*DIM+j]*new_sigma*new_sigma

for i in range(DIM):
	fgauss.write(str(new_mu[i]) + ' ')
fgauss.write('\n\n')
for i in range(DIM):
	for j in range(DIM):
		fgauss.write(str(new_cov[i*DIM+j]) + ' ')
	fgauss.write('\n')
fgauss.write('\n')
for i in range(DIM):
	fgauss.write(str(new_q[i]) + ' ')
fgauss.write('\n\n')
fgauss.write(str(new_sigma) + '\n\n')
for i in range(DIM):
	fgauss.write(str(new_p[i]) + ' ')
fgauss.write('\n')

traj_file = '../trajectory.dat'
ftraj = open(traj_file, 'a')
ftraj.write(new_generation + ' ')
for i in range(DIM):
	ftraj.write(str(new_mu[i]) + ' ')
ftraj.write('\n')
ftraj.close()

#estraggo altri 10 sample
#scrivo su un file della prossima cartella generation le nuove triplette dei nuovi sample
#scrivo anche un file per ogni sample dentro la cartella del sample con la sua tripletta e basta

sample_file = filepath + 'param_sample.dat'
fsample = open(sample_file, 'w')

samples = []

print(MeanValues)
print(Cov)

for i in range(nSamples):
	while(True):
		k = 0
   		samples.append(np.random.multivariate_normal(MeanValues,Cov))
   		#print(samples)
   		for j in range(DIM):
			if samples[i][j] < Lowest[j]:
				k += 1
			if samples[i][j] > Highest[j]:
				k += 1
		if k == 0:
			break
		else:
			samples.pop()


#scrivere sul file param_sample i parametri dei prossimi sample
for i in range(nSamples):
	fsample.write(str(i) + ' ')
	for j in range(DIM):
		fsample.write(str(samples[i][j]) +' ')
	fsample.write('\n')

for i in range(nSamples):
	file_name_siminfo = filepath + 'sample' + str(i) + '/siminfo.dat'
	fpinfo = open(file_name_siminfo, 'w+')
	for j in range(DIM):
		fpinfo.write(str(samples[i][j]) +' ')
	fpinfo.close()
