import linecache
import math
import numpy as np

lines = 99
fileIn = 'fitness.dat'
fileOut = open('maxfit.dat','w')
for thisLine in range(lines):
	allfitness = [float(a) for a in linecache.getline(fileIn,thisLine+1).split()]
	maxfit = np.min(np.array(allfitness))
	fileOut.write(str(1-maxfit) + '\n')
fileOut.close()

