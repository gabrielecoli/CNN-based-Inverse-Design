import linecache
import math
import numpy as np

lines = 99
fileIn = 'fitness.dat'
fileOut = open('newfit.dat','w')
for thisLine in range(lines):
	allfitness = [float(a) for a in linecache.getline(fileIn,thisLine+1).split()]
	avgfit = np.mean(np.array(allfitness))
	fileOut.write(str(avgfit) + '\n')
fileOut.close()

